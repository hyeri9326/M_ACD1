/**
* Multi-function Device Main Program
*
* Copyright 2021 by Home beauty Device Team, CLASSYS Inc.
* All rights reserved.
*
* CapTouch_I2C.h : This file contains Defines, Extern Variables and etc.
to control Capacitive Touch Driver IC.
*
* @author     Park, Sungjun
* @version    V0.00
* @date       12.14.2021
*/
#ifndef __Voice_I2C_H
#define __Voice_I2C_H

/* includes ------------------------------------------------------------------*/
#include "main.h"

/* defines -------------------------------------------------------------------*/
#define ADDR_SLAVE_VOICE	0xF3
#define P_DATA 				0x01
#define VOICE_1				0x00H

#define VOICE_LEVEL1		10
#define VOICE_LEVEL2		11
#define VOICE_LEVEL3		12
#define VOICE_LEVEL4		13
#define VOICE_LEVEL5		14
#define VOICE_ALARM1		25
#define VOICE_ALARM2		26	// Power Off
#define VOICE_ALARM3		27	// Power On
#define VOICE_ALARM4		28	// Treatment Done

/* structs -------------------------------------------------------------------*/
/* Extern Variables ----------------------------------------------------------*/
/* Extern struncts -----------------------------------------------------------*/
/* functions -----------------------------------------------------------------*/
void Init_Voice(uint8_t DDATA);
void VoiceOutput(uint8_t voiceNum);

#endif  /* __Voice_I2C_H__ */
